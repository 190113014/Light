SET SERVEROUTPUT ON;
DECLARE 
   CURSOR curs is 
      select DISTINCT brand from electro; 
   TYPE typ IS TABLE of electro.brand%type INDEX BY binary_integer; 
   name_typ typ; 
   counter integer :=0; 
BEGIN 
   FOR i IN curs LOOP 
      counter := counter +1; 
      name_typ(counter) := i.brand; 
      dbms_output.put_line('Brand('||counter||'):'||name_typ(counter)); 
   END LOOP; 
END;

SET SERVEROUTPUT ON;
DECLARE 
   CURSOR curs is 
      select DISTINCT CATEGORIES from electro; 
   TYPE typ IS TABLE of electro.CATEGORIES%type INDEX BY binary_integer; 
   name_typ typ; 
   counter integer :=0; 
BEGIN 
   FOR i IN curs LOOP 
      counter := counter +1; 
      name_typ(counter) := i.CATEGORIES; 
      dbms_output.put_line('Category('||counter||'):'||name_typ(counter)); 
   END LOOP; 
END;

set serveroutput on;

--���������� ����
DECLARE
    CURSOR curs IS
      SELECT id,
             PRICES_AMOUNTMAX
      FROM electro
      WHERE id = 2
      FOR UPDATE;
BEGIN
    FOR rec IN curs LOOP
        UPDATE electro
        SET PRICES_AMOUNTMAX= (PRICES_AMOUNTMAX * 115)/100
        WHERE CURRENT OF curs;
    END LOOP;
END;
/

--���������� ����
DECLARE
    CURSOR curs IS
      SELECT id,
             PRICES_AMOUNTMAX
      FROM electro
      WHERE id = 3
      FOR UPDATE;
BEGIN
    FOR rec IN curs LOOP
        UPDATE electro
        SET PRICES_AMOUNTMAX= PRICES_AMOUNTMAX * 0.1
        WHERE  CURRENT OF curs;
    END LOOP;
END;
/

--�����
create or replace function product_search(
v_id IN NUMBER) 
return electro%ROWTYPE
IS
  v_row electro%ROWTYPE;
Cursor search
IS
SELECT * FROM ELECTRO WHERE id = v_id;
BEGIN
OPEN search;
LOOP
FETCH search INTO v_row;
EXIT WHEN search%NOTFOUND;
END LOOP;
RETURN v_row;
END product_search;

--������� �������� ������ �� ����
CREATE OR REPLACE FUNCTION get_info(
      br IN electro.brand%TYPE)
   RETURN SYS_REFCURSOR
AS
   info SYS_REFCURSOR;
BEGIN
   OPEN info FOR 
   SELECT 
     AVG(PRICES_AMOUNTMAX)
   FROM 
      electro
   WHERE 
     brand  = br
   ORDER BY 
       brand;
   RETURN info;
END;

--������� � �����
create or replace function conv(
price IN NUMBER) 
return electro.id%TYPE
IS
  f_price electro.id%TYPE;
BEGIN
f_price := price * 427;
RETURN f_price;
END conv;

--������� � �����
create or replace function conv2(
price IN NUMBER) 
return electro.id%TYPE
IS
  f_price electro.id%TYPE;
BEGIN
f_price := price * 74.22;
RETURN f_price;
END conv;

SET SERVEROUTPUT ON;
DECLARE
f_price electro.id%TYPE;
BEGIN
f_price := conv(2);
dbms_output.put_line(f_price);
END;

SET SERVEROUTPUT ON;
DECLARE
f_price electro.id%TYPE;
BEGIN
f_price := conv(1);
dbms_output.put_line(f_price);
END;

DECLARE
   info SYS_REFCURSOR;
   new_name electro.name%TYPE;
BEGIN
   info := get_info('Sanus');  
   LOOP
      FETCH
         info
      INTO
       new_name;
      EXIT
   WHEN info%notfound;
      dbms_output.put_line(new_name);
   END LOOP;
   
   CLOSE info;
END;
/
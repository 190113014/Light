--����� � �����������
create or replace package proc 
as
PROCEDURE info_procedure (v_id NUMBER);
PROCEDURE insert_procedure
 (
    PRICES_AMOUNTMAX IN ELECTRO.PRICES_AMOUNTMAX%TYPE, 
    PRICES_AMOUNTMIN IN ELECTRO.PRICES_AMOUNTMIN%TYPE, 
    PRICES_AVAILABILITY IN ELECTRO.PRICES_AVAILABILITY%TYPE, 
    PRICES_CONDITION IN ELECTRO.PRICES_CONDITION%TYPE, 
    PRICES_CURRENCY IN ELECTRO.PRICES_CURRENCY%TYPE, 
    PRICES_DATESEEN IN ELECTRO.PRICES_DATESEEN%TYPE, 
    PRICES_ISSALE IN ELECTRO.PRICES_ISSALE%TYPE, 
    PRICES_MERCHANT IN ELECTRO.PRICES_MERCHANT%TYPE, 
    PRICES_SHIPPING IN ELECTRO.PRICES_SHIPPING%TYPE, 
    PRICES_SOURCEURLS IN ELECTRO.PRICES_SOURCEURLS%TYPE,
    BRAND IN ELECTRO.BRAND%TYPE,
    CATEGORIES IN ELECTRO.CATEGORIES%TYPE,
    DATEADDED IN ELECTRO.DATEADDED%TYPE,
    IMAGEURLS IN ELECTRO.IMAGEURLS%TYPE,
    KEYS IN ELECTRO.KEYS%TYPE,
    MANUFACTURER IN ELECTRO.MANUFACTURER%TYPE,
    NAME IN ELECTRO.NAME%TYPE,
    PRIMARYCATEGORIES IN ELECTRO.PRIMARYCATEGORIES%TYPE,
    SOURCEURLS IN ELECTRO.SOURCEURLS%TYPE,
    WEIGHT IN ELECTRO.WEIGHT%TYPE,
    ID IN ELECTRO.ID%TYPE
 );
procedure update_procedures(v_id in electro.id%type, 
v_priceMax in electro.PRICES_AMOUNTMAX%type, v_priceMin in electro.PRICES_AMOUNTMIN%type);
procedure delete_procedure(v_id in electro.id%type);
end proc;

create or replace package body proc
as
PROCEDURE info_procedure (
v_id NUMBER 
)
IS
  v_info Electro%ROWTYPE;
BEGIN
  SELECT *
  INTO v_info
  FROM Electro
  WHERE id = v_id;
  dbms_output.put_line('Name: ' || v_info.name);
  dbms_output.put_line('Price: ' || v_info.prices_amountMax || ' ' || v_info.prices_currency);
END;
PROCEDURE insert_procedure
 (
    PRICES_AMOUNTMAX IN ELECTRO.PRICES_AMOUNTMAX%TYPE, 
    PRICES_AMOUNTMIN IN ELECTRO.PRICES_AMOUNTMIN%TYPE, 
    PRICES_AVAILABILITY IN ELECTRO.PRICES_AVAILABILITY%TYPE, 
    PRICES_CONDITION IN ELECTRO.PRICES_CONDITION%TYPE, 
    PRICES_CURRENCY IN ELECTRO.PRICES_CURRENCY%TYPE, 
    PRICES_DATESEEN IN ELECTRO.PRICES_DATESEEN%TYPE, 
    PRICES_ISSALE IN ELECTRO.PRICES_ISSALE%TYPE, 
    PRICES_MERCHANT IN ELECTRO.PRICES_MERCHANT%TYPE, 
    PRICES_SHIPPING IN ELECTRO.PRICES_SHIPPING%TYPE, 
    PRICES_SOURCEURLS IN ELECTRO.PRICES_SOURCEURLS%TYPE,
    BRAND IN ELECTRO.BRAND%TYPE,
    CATEGORIES IN ELECTRO.CATEGORIES%TYPE,
    DATEADDED IN ELECTRO.DATEADDED%TYPE,
    IMAGEURLS IN ELECTRO.IMAGEURLS%TYPE,
    KEYS IN ELECTRO.KEYS%TYPE,
    MANUFACTURER IN ELECTRO.MANUFACTURER%TYPE,
    NAME IN ELECTRO.NAME%TYPE,
    PRIMARYCATEGORIES IN ELECTRO.PRIMARYCATEGORIES%TYPE,
    SOURCEURLS IN ELECTRO.SOURCEURLS%TYPE,
    WEIGHT IN ELECTRO.WEIGHT%TYPE,
    ID IN ELECTRO.ID%TYPE
 )
IS 
BEGIN  
INSERT INTO Electro
    (                    
    PRICES_AMOUNTMAX,
    PRICES_AMOUNTMIN,  
    PRICES_AVAILABILITY,  
    PRICES_CONDITION,
    PRICES_CURRENCY, 
    PRICES_DATESEEN, 
    PRICES_ISSALE, 
    PRICES_MERCHANT, 
    PRICES_SHIPPING, 
    PRICES_SOURCEURLS, 
    BRAND, 
    CATEGORIES, 
    DATEADDED, 
    IMAGEURLS, 
    KEYS, 
    MANUFACTURER, 
    NAME, 
    PRIMARYCATEGORIES, 
    SOURCEURLS, 
    WEIGHT, 
    ID
    ) 
     VALUES 
    ( 
        PRICES_AMOUNTMAX,
    PRICES_AMOUNTMIN,  
    PRICES_AVAILABILITY,  
    PRICES_CONDITION,
    PRICES_CURRENCY, 
    PRICES_DATESEEN, 
    PRICES_ISSALE, 
    PRICES_MERCHANT, 
    PRICES_SHIPPING, 
    PRICES_SOURCEURLS, 
    BRAND, 
    CATEGORIES, 
    DATEADDED, 
    IMAGEURLS, 
    KEYS, 
    MANUFACTURER, 
    NAME, 
    PRIMARYCATEGORIES, 
    SOURCEURLS, 
    WEIGHT, 
    ID
    );
COMMIT;
END;
procedure update_procedures(v_id in electro.id%type, 
v_priceMax in electro.PRICES_AMOUNTMAX%type, v_priceMin in electro.PRICES_AMOUNTMIN%type)
IS Begin
update electro set PRICES_AMOUNTMAX = v_priceMax,
PRICES_AMOUNTMIN = v_priceMin where id = v_id;
commit;
end;
procedure delete_procedure(v_id in electro.id%type)
is begin
delete electro where id = v_id;
commit;
end;
end proc;


--����� � ���������
create or replace package func
is
function product_search(v_id IN NUMBER) return electro%ROWTYPE;
FUNCTION get_info(br IN electro.brand%TYPE)RETURN SYS_REFCURSOR;
function conv(price IN NUMBER)return electro.id%TYPE;
function conv2(price IN NUMBER) return electro.id%TYPE;
end func;

create or replace package body func
is
function product_search(
v_id IN NUMBER) 
return electro%ROWTYPE
IS
  v_row electro%ROWTYPE;
Cursor search
IS
SELECT * FROM ELECTRO WHERE id = v_id;
BEGIN
OPEN search;
LOOP
FETCH search INTO v_row;
EXIT WHEN search%NOTFOUND;
END LOOP;
RETURN v_row;
END product_search;

FUNCTION get_info(
      br IN electro.brand%TYPE)
   RETURN SYS_REFCURSOR
AS
   info SYS_REFCURSOR;
BEGIN
   OPEN info FOR 
   SELECT 
     AVG(PRICES_AMOUNTMAX)
   FROM 
      electro
   WHERE 
     brand  = br
   ORDER BY 
       brand;
   RETURN info;
END;

function conv(
price IN NUMBER) 
return electro.id%TYPE
IS
  f_price electro.id%TYPE;
BEGIN
f_price := price * 427;
RETURN f_price;
END conv;

function conv2(
price IN NUMBER) 
return electro.id%TYPE
IS
  f_price electro.id%TYPE;
BEGIN
f_price := price * 74.22;
RETURN f_price;
END conv2;
End func;

SET SERVEROUTPUT ON;
DECLARE
f_price electro.id%TYPE;
BEGIN
f_price := conv(1);
dbms_output.put_line(f_price);
END;
end func;

SET SERVEROUTPUT ON;
DECLARE
d_id electro%ROWTYPE;
BEGIN
d_id := product_search(1);
dbms_output.put_line(d_id.PRICES_AMOUNTMAX || ' ' 
|| d_id.PRICES_AMOUNTMAX 
|| ' ' || d_id.PRICES_AMOUNTMAX 
|| ' ' || d_id.PRICES_AMOUNTMIN 
|| ' ' ||d_id.PRICES_AVAILABILITY 
|| ' ' ||d_id.PRICES_CONDITION 
|| ' ' ||d_id.PRICES_CURRENCY 
|| ' ' ||d_id.PRICES_DATESEEN 
|| ' ' ||d_id.PRICES_ISSALE 
|| ' ' ||d_id.PRICES_MERCHANT 
|| ' ' ||d_id.PRICES_SHIPPING 
|| ' ' ||d_id.PRICES_SOURCEURLS 
|| ' ' ||d_id.BRAND 
|| ' ' ||d_id.CATEGORIES 
|| ' ' ||d_id.DATEADDED 
|| ' ' ||d_id.IMAGEURLS 
|| ' ' ||d_id.KEYS 
|| ' ' ||d_id.MANUFACTURER 
|| ' ' ||d_id.NAME 
|| ' ' ||d_id.PRIMARYCATEGORIES 
|| ' ' ||d_id.SOURCEURLS 
|| ' ' ||d_id.WEIGHT 
|| ' ' ||d_id.ID 
);
END;